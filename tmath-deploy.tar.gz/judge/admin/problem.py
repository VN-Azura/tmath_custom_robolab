from operator import attrgetter

from django import forms
from django.contrib import admin
from django.db import transaction
from django.db.models import Count
from django.forms import ModelForm
from django.http import HttpRequest
from django.urls import reverse_lazy
from django.utils import timezone
from django.utils.html import format_html
from django.utils.translation import gettext
from django.utils.translation import gettext_lazy as _
from django.utils.translation import ngettext
from reversion.admin import VersionAdmin

from judge.models import (LanguageLimit, Problem, ProblemClarification,
                          ProblemTranslation, Profile, Solution)
from judge.models.problem import ProblemClass, ProblemGroup, ProblemType
from judge.utils.views import NoBatchDeleteMixin
from judge.widgets import (AdminMartorWidget,
                           CheckboxSelectMultipleWithSelectAll)


class ProblemForm(ModelForm):
    change_message = forms.CharField(max_length=256, label='Edit reason', required=False)
    # classes = forms.CharField(max_length=255, label="Problem class", required=True)

    def __init__(self, *args, **kwargs):
        super(ProblemForm, self).__init__(*args, **kwargs)
        self.fields['authors'].widget.can_add_related = False
        self.fields['curators'].widget.can_add_related = False
        self.fields['testers'].widget.can_add_related = False
        self.fields['banned_users'].widget.can_add_related = False
        self.fields['change_message'].widget.attrs.update({
            'placeholder': gettext('Describe the changes you made (optional)'),
        })

    class Meta:
        widgets = {
            'description': AdminMartorWidget(attrs={'data-markdownfy-url': reverse_lazy('problem_preview')}),
        }


class ProblemCreatorListFilter(admin.SimpleListFilter):
    title = parameter_name = 'creator'

    def lookups(self, request, model_admin):
        queryset = Profile.objects.exclude(authored_problems=None).values_list('user__username', flat=True)
        return [(name, name) for name in queryset]

    def queryset(self, request, queryset):
        if self.value() is None:
            return queryset
        return queryset.filter(authors__user__username=self.value())


class ProblemGroupFilter(admin.SimpleListFilter):
    title = parameter_name = 'group'

    def lookups(self, request, model_admin):
        queryset = ProblemGroup.objects.values_list('name', 'full_name')
        return [(name, fullname) for name, fullname in queryset]

    def queryset(self, request, queryset):
        if self.value() is None:
            return queryset
        return queryset.filter(group__name=self.value())


class ProblemTypeFilter(admin.SimpleListFilter):
    title = parameter_name = 'type'

    def lookups(self, request, model_admin):
        queryset = ProblemType.objects.values_list('name', 'full_name')
        return [(name, fullname) for name, fullname in queryset]

    def queryset(self, request, queryset):
        if self.value() is None:
            return queryset
        return queryset.filter(types__name=self.value())


class ProblemClassFilter(admin.SimpleListFilter):
    title = parameter_name = 'class'

    def lookups(self, request, model_admin):
        queryset = ProblemClass.objects.values_list('name', 'full_name')
        return [(name, fullname) for name, fullname in queryset]

    def queryset(self, request, queryset):
        if self.value() is None:
            return queryset
        return queryset.filter(classes__name=self.value())


class LanguageLimitInline(admin.TabularInline):
    model = LanguageLimit
    fields = ('language', 'time_limit', 'memory_limit')
    autocomplete_fields = ['language']


class ProblemClarificationForm(ModelForm):
    class Meta:
        widgets = {'description': AdminMartorWidget(attrs={'data-markdownfy-url': reverse_lazy('comment_preview')})}


class ProblemClarificationInline(admin.StackedInline):
    model = ProblemClarification
    fields = ('description',)
    form = ProblemClarificationForm
    extra = 0


class ProblemSolutionForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(ProblemSolutionForm, self).__init__(*args, **kwargs)
        self.fields['authors'].widget.can_add_related = False

    class Meta:
        widgets = {
            'content': AdminMartorWidget(attrs={'data-markdownfy-url': reverse_lazy('solution_preview')}),
        }


class ProblemSolutionInline(admin.StackedInline):
    model = Solution
    fields = ('is_public', 'publish_on', 'authors', 'is_full_markup', 'content')
    form = ProblemSolutionForm
    extra = 0
    autocomplete_fields = ['authors']


class ProblemTranslationForm(ModelForm):
    class Meta:
        widgets = {'description': AdminMartorWidget(attrs={'data-markdownfy-url': reverse_lazy('problem_preview')})}


class ProblemTranslationInline(admin.StackedInline):
    model = ProblemTranslation
    fields = ('language', 'name', 'description')
    form = ProblemTranslationForm
    extra = 0

    def has_permission_full_markup(self, request, obj=None):
        if not obj:
            return True
        return request.user.has_perm('judge.problem_full_markup') or not obj.is_full_markup

    has_add_permission = has_change_permission = has_delete_permission = has_permission_full_markup


class HasTestCaseFilter(admin.SimpleListFilter):
    title = 'has test cases'
    parameter_name = 'has_test_cases'

    def lookups(self, request, model_admin):
        return (
            ('1', _('Has test cases')),
            ('0', _('No test cases')),
        )

    def queryset(self, request, queryset):
        if self.value() == '1':
            return queryset.annotate(testcase_count=Count('cases')).filter(testcase_count__gt=0)
        if self.value() == '0':
            return queryset.annotate(testcase_count=Count('cases')).filter(testcase_count=0)


class ProblemAdmin(NoBatchDeleteMixin, VersionAdmin):
    change_form_template = 'admin/judge/problem/change_form.html'
    fieldsets = (
        (None, {
            'fields': (
                'code', 'name', 'approved', 'is_public', 'is_manually_managed', 'date',
                'authors', 'curators', 'testers',
                'is_organization_private', 'organizations', 'submission_source_visibility_mode', 'is_full_markup',
                'public_description', 'description', 'license', 'testcase_visibility_mode',
            ),
        }),
        (_('Social Media'), {'classes': ('grp-collapse grp-open',), 'fields': ('og_image', 'summary')}),
        (_('Taxonomy'), {'fields': ('classes', 'types', 'group')}),
        (_('Points'), {'fields': (('points', 'partial'), 'short_circuit')}),
        (_('Limits'), {'fields': ('time_limit', 'memory_limit')}),
        (_('Language'), {'fields': ('allowed_languages',)}),
        (_('Justice'), {'fields': ('banned_users',)}),
        (_('History'), {'fields': ('change_message',)}),
    )
    autocomplete_fields = [
        'authors',
        'curators',
        'testers',
        'organizations',
        'banned_users',
        'classes',
        'types',
        'group',
        'license',
    ]
    list_display = ['code', 'name', 'show_authors', 'display_types', 'classes', 'is_public', 'approved', 'show_public']
    ordering = ['code']
    search_fields = ('code', 'name', 'types__name', 'classes__name', 'group__name')
    inlines = [
        LanguageLimitInline,
        ProblemClarificationInline,
        ProblemSolutionInline,
        ProblemTranslationInline,
    ]
    list_max_show_all = 1000
    actions_on_top = True
    actions_on_bottom = True
    list_filter = (
        'is_public',
        ProblemCreatorListFilter,
        ProblemClassFilter,
        ProblemGroupFilter,
        ProblemTypeFilter,
        HasTestCaseFilter,
    )
    form = ProblemForm
    date_hierarchy = 'date'

    def display_types(self, obj):
        return ", ".join([type.name for type in obj.types.all()])
    display_types.short_description = _('Types')

    def get_actions(self, request):
        actions = super(ProblemAdmin, self).get_actions(request)

        if request.user.has_perm('judge.change_public_visibility'):
            func, name, desc = self.get_action('make_public')
            actions[name] = (func, name, desc)

            func, name, desc = self.get_action('make_private')
            actions[name] = (func, name, desc)

        if request.profile.super_admin:
            func, name, desc = self.get_action('make_approved')
            actions[name] = (func, name, desc)

        func, name, desc = self.get_action('update_publish_date')
        actions[name] = (func, name, desc)

        return actions

    def get_readonly_fields(self, request, obj=None):
        fields = self.readonly_fields
        if not request.user.has_perm('judge.change_public_visibility'):
            fields += ('is_public',)
        if not request.user.has_perm('judge.change_manually_managed'):
            fields += ('is_manually_managed',)
        if not request.user.has_perm('judge.problem_full_markup'):
            fields += ('is_full_markup',)
            if obj and obj.is_full_markup:
                fields += ('description',)
        if not request.profile.super_admin:
            fields += ('approved',)
        return fields

    def show_authors(self, obj):
        return ', '.join(map(attrgetter('user.username'), obj.authors.all()))

    show_authors.short_description = _('Authors')

    def show_public(self, obj):
        return format_html('<a href="{1}">{0}</a>', gettext('View on site'), obj.get_absolute_url())

    show_public.short_description = ''

    def _rescore(self, request, problem_id):
        from judge.tasks import rescore_problem
        transaction.on_commit(rescore_problem.s(problem_id).delay)

    def update_publish_date(self, request, queryset):
        count = queryset.update(date=timezone.now())
        self.message_user(request, ngettext("%d problem's publish date successfully updated.",
                                            "%d problems' publish date successfully updated.",
                                            count) % count)

    update_publish_date.short_description = _('Set publish date to now')

    def make_public(self, request, queryset):
        count = queryset.update(is_public=True)
        for problem_id in queryset.values_list('id', flat=True):
            self._rescore(request, problem_id)
        self.message_user(request, ngettext('%d problem successfully marked as public.',
                                            '%d problems successfully marked as public.',
                                            count) % count)

    make_public.short_description = _('Mark problems as public')

    def make_private(self, request, queryset):
        count = queryset.update(is_public=False)
        for problem_id in queryset.values_list('id', flat=True):
            self._rescore(request, problem_id)
        self.message_user(request, ngettext('%d problem successfully marked as private.',
                                            '%d problems successfully marked as private.',
                                            count) % count)

    make_private.short_description = _('Mark problems as private')

    def make_approved(self, request, queryset):
        count = queryset.update(approved=True)
        self.message_user(request, ngettext('%d problem successfully marked as approved.',
                                            '%d problems successfully marked as approved.',
                                            count) % count)
    make_approved.short_description = _('Mark problems as approved')

    def get_queryset(self, request):
        return Problem.get_editable_problems(request.user).prefetch_related('authors__user').distinct()

    def has_change_permission(self, request, obj=None):
        if obj is None:
            return request.user.has_perm('judge.edit_own_problem')
        return obj.is_editable_by(request.user)

    def formfield_for_manytomany(self, db_field, request=None, **kwargs):
        if db_field.name == 'allowed_languages':
            kwargs['widget'] = CheckboxSelectMultipleWithSelectAll()
        return super(ProblemAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)

    def get_form(self, *args, **kwargs):
        form = super(ProblemAdmin, self).get_form(*args, **kwargs)
        form.base_fields['authors'].queryset = Profile.objects.all()
        return form

    def save_model(self, request, obj, form, change):
        super(ProblemAdmin, self).save_model(request, obj, form, change)
        if (
            form.changed_data and
            any(f in form.changed_data for f in ('is_public', 'is_organization_private', 'points', 'partial'))
        ):
            self._rescore(request, obj.id)

    def construct_change_message(self, request, form, *args, **kwargs):
        if form.cleaned_data.get('change_message'):
            return form.cleaned_data['change_message']
        return super(ProblemAdmin, self).construct_change_message(request, form, *args, **kwargs)

    def get_search_results(self, request, queryset, search_term):
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)
        if 'autocomplete' in request.path:
            if request.GET.get('model_name') == 'contestproblem' and request.GET.get('field_name') == 'problem':
                queryset = queryset.annotate(case_count=Count('cases')) \
                    .filter(case_count__gt=0, approved=True).order_by('-pk')
            if request.GET.get('model_name') == 'publicproblem' and request.GET.get('field_name') == 'problem':
                queryset = queryset.annotate(case_count=Count('cases')) \
                    .filter(case_count__gt=0, is_public=False).order_by('-pk')
        return queryset, use_distinct


class PublicSolutionAdminForm(ModelForm):
    class Meta:
        widgets = {
            'description': AdminMartorWidget(attrs={'data-markdownfy-url': reverse_lazy('problem_preview')}),
        }


class PublicSolutionAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {
            "fields": (
                'author', 'problem', 'created',
            ),
        }),
        ('Assessment', {
            "fields": (
                'approved', 'point', 'score',
            ),
        }),
        ('Solution', {
            'fields': (
                'description',
            ),
        }),
    )

    form = PublicSolutionAdminForm
    readonly_fields = ['author', 'problem', 'created', 'score']

    def get_actions(self, request):
        actions = super().get_actions(request)

        func, name, desc = self.get_action('approve_all_solution')
        actions[name] = (func, name, desc)

        return actions

    def approve_all_solution(self, request, queryset):
        count = queryset.update(approved=True)
        self.message_user(request, ngettext('%d solution successfully marked as approve.',
                                            '%d solutions successfully marked as approve.',
                                            count) % count)

    approve_all_solution.short_description = _('Mark solutions as approve')


class LogDownloadTestCaseAdmin(admin.ModelAdmin):
    list_display = ['id', 'problem', 'user', 'order', 'created']
    # list_filter = ['problem', 'user']
    search_fields = ['problem__code', 'problem__name', 'user__user__username', 'user__name']
    readonly_fields = ['problem', 'user', 'created', 'order']

    def has_add_permission(self, request: HttpRequest) -> bool:
        return False
